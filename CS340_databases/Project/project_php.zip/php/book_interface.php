<?php
//Turn on error reporting
ini_set('display_errors', 'On');
//Connects to the database
$mysqli = new mysqli("oniddb.cws.oregonstate.edu","murpchar-db","r1idCMXOI59XTDTn","murpchar-db");
if($mysqli->connect_errno){
	echo "Connection error " . $mysqli->connect_errno . " " . $mysqli->connect_error;
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<body>

<!--  Display contents of book table. 
	Select query replaces foreign key id values
	with values associated with ids
	ex: author.id is replaced with author name-->
<div>
	<table>
		<tr>
			<td>Books </td>
		</tr>
		<tr>
			<td>ID</td>
			<td>Title</td>
			<td>Pages</td>
			<td>Author_ID</td>
			<td>Genre_ID</td>
			<td>Location_ID</td>
		</tr>
<?php
if(!($stmt = $mysqli->prepare("SELECT book.id, book.title, book.pages, concat(author.fname, ' ', author.lname) AS Author, 
	genre.genre_name, location.location_name FROM book INNER JOIN
    author ON book.aid = author.id INNER JOIN
    genre ON book.gid = genre.id INNER JOIN
    location ON book.lid = location.id
    ORDER BY book.title"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($ID, $Title, $Pages, $Author_ID, $Genre_ID, $Location_ID)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
 echo "<tr>\n<td>\n" . $ID . "\n</td>\n<td>\n" . $Title . "\n</td>\n<td>\n" . $Pages . "\n</td>\n<td>\n" . $Author_ID . "\n</td>\n<td>\n" . $Genre_ID . "\n</td>\n<td>\n" . $Location_ID . "\n</td>\n</tr>";
}
$stmt->close();
?>
	</table>
</div>



</br></br>


<!--  Display all books ordered by author name and then by title  -->
<div>
	<table>
		<tr>
			<td>Books by Author </td>
		</tr>
		<tr>
			<td>Author</td>
			<td>Title</td>
		</tr>
<?php
if(!($stmt = $mysqli->prepare("SELECT concat(author.fname, ' ', author.lname) AS Author, book.title  FROM book 
	INNER JOIN author ON book.aid = author.id
    ORDER BY author.lname, book.title"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($Author, $Title)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
 echo "<tr>\n<td>\n" . $Author . "\n</td>\n<td>\n" . $Title . "\n</td>\n</tr>";
}
$stmt->close();
?>
	</table>
</div>



</br></br>



<!--  Display contents of author table  -->
<div>
	<table>
		<tr>
			<td>Authors </td>
		</tr>
		<tr>
			<td>ID</td>
			<td>First</td>
			<td>Last</td>
		</tr>
<?php
if(!($stmt = $mysqli->prepare("SELECT author.id, author.fname, author.lname FROM author
	ORDER BY author.lname"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($ID, $First, $Last)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
 echo "<tr>\n<td>\n" . $ID . "\n</td>\n<td>\n" . $First . "\n</td>\n<td>\n" . $Last . "\n</td>\n</tr>";
}
$stmt->close();
?>
	</table>
</div>



</br></br>


<!--  Display contents of genre table  -->
<div>
	<table>
		<tr>
			<td>Genre </td>
		</tr>
		<tr>
			<td>ID</td>
			<td>Name</td>
		</tr>
<?php
if(!($stmt = $mysqli->prepare("SELECT genre.id, genre.genre_name FROM genre
	ORDER BY genre.genre_name"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($ID, $Name)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
 echo "<tr>\n<td>\n" . $ID . "\n</td>\n<td>\n" . $Name . "\n</td>\n</tr>";
}
$stmt->close();
?>
	</table>
</div>



</br></br>



<!--  Display contents of location table  -->
<div>
	<table>
		<tr>
			<td>Locations </td>
		</tr>
		<tr>
			<td>ID</td>
			<td>Name</td>
		</tr>
<?php
if(!($stmt = $mysqli->prepare("SELECT location.id, location.location_name FROM location
	ORDER BY location.id"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($ID, $Name)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
 echo "<tr>\n<td>\n" . $ID . "\n</td>\n<td>\n" . $Name . "\n</td>\n</tr>";
}
$stmt->close();
?>
	</table>
</div>



</br></br>



<!--  Display contents of reader table  -->
<div>
	<table>
		<tr>
			<td>Readers </td>
		</tr>
		<tr>
			<td>ID</td>
			<td>First</td>
			<td>Last</td>
		</tr>
<?php
if(!($stmt = $mysqli->prepare("SELECT reader.id, reader.fname, reader.lname FROM reader
	ORDER BY reader.id"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($ID, $First, $Last)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
 echo "<tr>\n<td>\n" . $ID . "\n</td>\n<td>\n" . $First . "\n</td>\n<td>\n" . $Last . "\n</td>\n</tr>";
}
$stmt->close();
?>
	</table>
</div>



</br></br>



<!--  Display contents of has_read table  -->
<div>
	<table>
		<tr>
			<td>Books Readers have Read </td>
		</tr>
		<tr>
			<td>Reader</td>
			<td>Book</td>
		</tr>
<?php
if(!($stmt = $mysqli->prepare("SELECT concat(reader.fname, ' ', reader.lname) AS Reader, book.title FROM has_read INNER JOIN
	reader ON has_read.rid = reader.id INNER JOIN
    book ON has_read.bid = book.id
    ORDER BY has_read.rid"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($Reader_ID, $Book_ID)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
 echo "<tr>\n<td>\n" . $Reader_ID . "\n</td>\n<td>\n" . $Book_ID . "\n</td>\n</tr>";
}
$stmt->close();
?>
	</table>
</div>



</br></br>



<!--  Display contents of will_read table  -->
<div>
	<table>
		<tr>
			<td>Books Readers will Read Next </td>
		</tr>
		<tr>
			<td>Reader</td>
			<td>Book</td>
			<td>Priority</td>
		</tr>
<?php
if(!($stmt = $mysqli->prepare("SELECT concat(reader.fname, ' ', reader.lname) AS Reader, book.title, priority FROM will_read INNER JOIN
	reader ON will_read.rid = reader.id INNER JOIN
    book ON will_read.bid = book.id
    ORDER BY will_read.rid"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($Reader_ID, $Book_ID, $Priority)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
 echo "<tr>\n<td>\n" . $Reader_ID . "\n</td>\n<td>\n" . $Book_ID . "\n</td>\n<td>\n" . $Priority . "\n</td>\n</tr>";
}
$stmt->close();
?>
	</table>
</div>



</br></br>



<!--  Form to add a new row to the reader table. 
		No foreign key references
		inserts into respective fields
		reader.id is autoincremented  -->
<div>
	<form method="post" action="add_reader.php"> 
		<fieldset>
			<legend>Add Reader</legend>
			<p>First Name: <input type="text" name="FirstName" /></p>
			<p>Last Name: <input type="text" name="LastName" /></p>
		</fieldset>		
		<p><input type="submit" value="Add Reader" /></p>
	</form>
</div>



</br></br>



<!--  Form to add a new row to the location table. 
		No foreign key references
		inserts strings into respective fields
		location.id is autoincremented  -->
<div>
	<form method="post" action="add_location.php"> 
		<fieldset>
			<legend>Add Location</legend>
			<p>Location Name: <input type="text" name="LocationName" /></p>
		</fieldset>		
		<p><input type="submit" value="Add Location" /></p>
	</form>
</div>



</br></br>



<!--  Form to add a new row to the genre table. 
		No foreign key references, just inserts strings
		into respective fields  -->
<div>
	<form method="post" action="add_genre.php"> 
		<fieldset>
			<legend>Add a Genre</legend>
			<p>Genre Name: <input type="text" name="GenreName" /></p>
		</fieldset>		
		<p><input type="submit" value="Add Genre" /></p>
	</form>
</div>



</br></br>



<!--  Form to add a new row to the author table. 
		No foreign key references, 
		insert text into respective fields
		autoincrement author.id  -->
<div>
	<form method="post" action="add_author.php"> 
		<fieldset>
			<legend>Add Author</legend>
			<p>First Name: <input type="text" name="FirstName" /></p>
			<p>Last Name: <input type="text" name="LastName" /></p>
		</fieldset>		
		<p><input type="submit" value="Add Author" /></p>
	</form>
</div>



</br></br></br>



<!--  Form to add a new row to the book table. 
		Drop down tables to selct values for 
		foreign key references: aid = author.id, 
		gid=genre.id, and lid=location.id.
		Insert text for other fields
		Autoincrement book.id  -->
<div>
	<form method="post" action="add_book.php"> 

		<fieldset>
			<legend>Title</legend>
			<p>Title: <input type="text" name="Title" /></p>
		</fieldset>

		<fieldset>
			<legend>Pages</legend>
			<p>Pages: <input type="number" name="Pages" /></p>
		</fieldset>
			
		<fieldset>
			<legend>Author</legend>
			<select name="Author">
<?php
if(!($stmt = $mysqli->prepare("SELECT id, concat(author.fname, ' ', author.lname) AS name 
	FROM author
	ORDER BY author.lname"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($id, $aname)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
	echo '<option value=" '. $id . ' "> ' . $aname . '</option>\n';
}
$stmt->close();
?>
			</select>
		</fieldset>

		<fieldset>
			<legend>Genre</legend>
			<select name="Genre">
<?php
if(!($stmt = $mysqli->prepare("SELECT id, genre_name FROM genre
	ORDER BY genre.genre_name"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($id, $gname)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
	echo '<option value=" '. $id . ' "> ' . $gname . '</option>\n';
}
$stmt->close();
?>
			</select>
		</fieldset>

		<fieldset>
			<legend>Location</legend>
			<select name="Location">
<?php
if(!($stmt = $mysqli->prepare("SELECT id, location_name FROM location
	ORDER BY location.id"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($id, $lname)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
	echo '<option value=" '. $id . ' "> ' . $lname . '</option>\n';
}
$stmt->close();
?>
			</select>
		</fieldset>
		<p><input type="submit" value="Add Book" /></p>
	</form>
</div>



</br></br>



<!--  Form to add a new row to the has_read table. 
		Drop down tables to selct values for 
		foreign key references: rid = reader.id, 
		bid = book.id  -->
<div>
	<form method="post" action="add_has_read.php"> 

		<fieldset>
			<legend>Reader</legend>
			<select name="Reader">
<?php
if(!($stmt = $mysqli->prepare("SELECT id, concat(reader.fname, ' ', reader.lname) AS name 
	FROM reader
	ORDER BY reader.id"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($id, $rname)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
	echo '<option value=" '. $id . ' "> ' . $rname . '</option>\n';
}
$stmt->close();
?>
			</select>
		</fieldset>

		<fieldset>
			<legend>Book</legend>
			<select name="Book">
<?php
if(!($stmt = $mysqli->prepare("SELECT id, title FROM book
	ORDER BY book.title"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($id, $bname)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
	echo '<option value=" '. $id . ' "> ' . $bname . '</option>\n';
}
$stmt->close();
?>
			</select>
		</fieldset>

		<p><input type="submit" value="Add Has Read" /></p>
	</form>
</div>



</br></br>



<!--  Form to add a new row to the will_read table. 
		Drop down tables to selct values for 
		foreign key references: rid = reader.id, 
		bid = book.id
		Insert text for other fields  -->
<div>
	<form method="post" action="add_will_read.php"> 

		<fieldset>
			<legend>Reader</legend>
			<select name="Reader">
<?php
if(!($stmt = $mysqli->prepare("SELECT id, concat(reader.fname, ' ', reader.lname) AS name 
	FROM reader
	ORDER BY reader.id"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($id, $rname)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
	echo '<option value=" '. $id . ' "> ' . $rname . '</option>\n';
}
$stmt->close();
?>
			</select>
		</fieldset>

		<fieldset>
			<legend>Book</legend>
			<select name="Book">
<?php
if(!($stmt = $mysqli->prepare("SELECT id, title FROM book
	ORDER BY book.title"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($id, $bname)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
	echo '<option value=" '. $id . ' "> ' . $bname . '</option>\n';
}
$stmt->close();
?>
			</select>
		</fieldset>

		<fieldset>
			<legend>Priority</legend>
			<p>Priority: <input type="number" name="Priority" /></p>
		</fieldset>

		<p><input type="submit" value="Add Will Read" /></p>
	</form>
</div>



</br></br>



<!--  Form to search for books by location. 
		Drop down menu to selct values for existing locations
		Returns Book.title, author.fname + author.lname, 
		location.location_name  -->
<div>
	<form method="post" action="search_location.php">
		<fieldset>
			<legend>Search By Location</legend>
				<select name="Location_Books">
					<?php
					if(!($stmt = $mysqli->prepare("SELECT location.id, location.location_name FROM location
						ORDER BY location.id"))){
						echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
					}

					if(!$stmt->execute()){
						echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
					}
					if(!$stmt->bind_result($id, $l_name)){
						echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
					}
					while($stmt->fetch()){
					 echo '<option value=" '. $id . ' "> ' . $l_name . '</option>\n';
					}
					$stmt->close();
					?>
				</select>
		</fieldset>
		<p><input type="submit" value="Search" /></p>
	</form>
</div>



</br></br>



<!--  Form to update the location of a book. 
		Drop down menus to choose from existing books
		by title and to choose from exsiting locations.
		Updates selected book's lid based on location
		selected from the drop down menu. 
		If the location selected is the current location
		of the book, then the page will display
		"Updated 0 rows in location"  -->
<div>
	<form method="post" action="update_location.php"> 

		<fieldset>
			<legend>Title</legend>
			<select name="Title">
<?php
if(!($stmt = $mysqli->prepare("SELECT id, title FROM book
	ORDER BY book.title"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($id, $btitle)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
	echo '<option value=" '. $id . ' "> ' . $btitle . '</option>\n';
}
$stmt->close();
?>
			</select>
		</fieldset>

		<fieldset>
			<legend>New Location</legend>
			<select name="Location">
<?php
if(!($stmt = $mysqli->prepare("SELECT id, location_name FROM location
	ORDER BY location.id"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($id, $lname)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
	echo '<option value=" '. $id . ' "> ' . $lname . '</option>\n';
}
$stmt->close();
?>
			</select>
		</fieldset>

		<p><input type="submit" value="Update Book Location" /></p>
	</form>
</div>

</br></br>
</br></br>
</br></br>
</br></br>

</body>
</html>