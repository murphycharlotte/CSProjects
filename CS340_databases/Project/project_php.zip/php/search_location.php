<?php
//Turn on error reporting
ini_set('display_errors', 'On');
//Connects to the database
$mysqli = new mysqli("oniddb.cws.oregonstate.edu","murpchar-db","r1idCMXOI59XTDTn","murpchar-db");

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<body>
<div>
	<table>
		<tr>
			<td>Books at Location</td>
		</tr>
		<tr>
			<td>Title</td>
			<td>Author</td>
			<td>Location</td>
		</tr>
		
<!--  Return title, author name, and location of all books at location.id received in param -->
<?php
if(!($stmt = $mysqli->prepare("SELECT book.title, concat(author.fname, ' ', author.lname) AS Author, location.location_name FROM book INNER JOIN
	author ON book.aid = author.id INNER JOIN
	location on book.lid = location.id
	WHERE location.id = ?"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!($stmt->bind_param("i",$_POST['Location_Books']))){
	echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}

if(!$stmt->bind_result($Title, $Author, $Location)){
	echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}

while($stmt->fetch()){
 echo "<tr>\n<td>\n" . $Title . "\n</td>\n<td>\n" . $Author . "\n</td>\n<td>\n" . $Location . "\n</td>\n</tr>";
}

$stmt->close();
?>
	</table>
</div>



</br></br>



<!-- Return to interface -->
<div>
	<form method="post" action="book_interface.php"> 
		<p><input type="submit" value="Home" /></p>
	</form>
</div>

</body>
</html>