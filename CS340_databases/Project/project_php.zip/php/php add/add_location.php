<?php
//Turn on error reporting
ini_set('display_errors', 'On');
//Connects to the database
$mysqli = new mysqli("oniddb.cws.oregonstate.edu","murpchar-db","r1idCMXOI59XTDTn","murpchar-db");

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<body>
	<div>
	<!-- Adds new row to location table per params received -->
<?php
if(!($stmt = $mysqli->prepare("INSERT INTO location(location.location_name) VALUES (?)"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!($stmt->bind_param("s",$_POST['lname']))){
	echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
} else {
	echo "Added " . $stmt->affected_rows . " rows to location.";
}
?>	
	</div>
	


	</br>
	


	<!-- Return to interface -->
	<div>
		<form method="post" action="book_interface.php"> 
			<p><input type="submit" value="Back" /></p>
		</form>
	</div>

</body>
</html>



