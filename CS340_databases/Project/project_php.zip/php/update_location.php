<?php
//Turn on error reporting
ini_set('display_errors', 'On');
//Connects to the database
$mysqli = new mysqli("oniddb.cws.oregonstate.edu","murpchar-db","r1idCMXOI59XTDTn","murpchar-db");

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<body>
	<div>

	<!-- Receives a book.id and a location.id and sets the book.lid = location.id param  -->
<?php
if(!($stmt = $mysqli->prepare("UPDATE book SET book.lid = ? WHERE book.id= ?"))){
	echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!($stmt->bind_param("ii",$_POST['Location'],$_POST['Title']))){
	echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}

if(!$stmt->execute()){
	echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
} else {
	echo "Updated " . $stmt->affected_rows . " rows in location.";
}

$stmt->close();
?>	
	</div>
	


</br></br>
	


	<!-- Return to interface -->
	<div>
		<form method="post" action="book_interface.php"> 
			<p><input type="submit" value="Back" /></p>
		</form>
	</div>

</body>
</html>


